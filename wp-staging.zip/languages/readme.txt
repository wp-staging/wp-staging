********************************************************

  Staging I18n
  ============================
  
  Do not put custom translations here. They will be deleted
  on Staging updates.
  
  Keep custom WPSTG translations in /wp-content/languages/staging/
  
  You want to translate, help, or improve a translation?
  Write: info@wp-staging.net

  More info at https://www.wp-staging.net/

********************************************************
