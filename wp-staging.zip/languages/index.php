<?php
/**
 * Do not put custom translations here. They will be deleted on Staging updates.
 *
 * Keep custom WPSTG translations in /wp-content/languages/wpstg/
 */