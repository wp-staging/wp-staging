#  Staging I18n #

  To help translate, review, or improve a translation, write Rene Hermenau at info@wp-staging.net

  More info at https://www.wp-staging.net/

# Quick Start #

    In staging/languages/ you find a file named wpstg.po

    - Open it with the free editor: http://poedit.net/

    - Translate the strings and save it. Poedit automatically creates the file wpstg.mo

    - Rename this to your language specific translation. E.g. for italy the file is called wpstg-it_IT.mo and put it into the folder /wp-content/languages/staging/

If you like to send us new mo files we will put it into this plugin package.

